package com.dl.uddi.action;

public interface IAction {
	void dealAction(String value);
}
