package com.dl.uddi.test;

import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;

import com.dl.uddi.core.Server;

public class Test {
	
		public static void main(String[] args) {
			Server server= new Server();
			server.setPort(50000);
			server.startup();
			
			try {
				Socket socket = new Socket("192.168.1.133", 50000);
				DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
//				dos.writeUTF("");
			} catch (IOException e) {
				e.printStackTrace();
			}
			
		}
}